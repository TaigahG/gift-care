import { useState } from 'react';
import { dapps_donate_backend } from 'declarations/dapps-donate-backend';
import lg1 from '../public/GiftCareLogo1.png'
import lg2 from '../public/GiftCare.png'
import lovepic from '../public/Love-Donation.png'
import Rohingnya from '../public/Rohingya.png'
import brazil from '../public/Brazil-flood.png'
import turkey from '../public/Turkey-earthquake.png'
import lgx from '../public/x.png'
import lgd from '../public/d.png'
import lgt from '../public/t.png'
import './index.css';

function App() {
  const [greeting, setGreeting] = useState('');

  function handleSubmit(event) {
    event.preventDefault();
    const name = event.target.elements.name.value;
    dapps_donate_backend.greet(name).then((greeting) => {
      setGreeting(greeting);
    });
    return false;
  }

  return (
    <main>
      {/* navbar */}
      <section className='nav'>
        <img src={lg2} alt="logo" id='navlg' />
        <div className="navlinks">
          <ul>
            <li><a href="" id='nava'><b>Home</b></a></li>
            <li><a href="" id='nava'>Ongoing Charity</a></li>
            <li><a href="" id='nava'>About Us</a></li>
          </ul>
        </div>
      </section>
      {/* bagan 1 */}
      <section className="bagan1">
        <img src={lg1} alt="giftcarelogo" id="logogambar" />
        <p className='p1'>With GiftCare, the community decides who receives support. Our voting system lets you choose the causes and individuals that matter most. Together, we can ensure that your generosity makes a real difference.
        </p>
        <div className="B1button">
          <button type="button" id="startdonate">Start Donate</button>
          <button type="button" id="RequestDonation">Request Donation</button>
        </div>
      </section>
      {/* bagan 2 */}
      <section className="bagan2">
        <div className="B2gambar">
          <img src={lovepic} alt="loveillustration" id="B2img" />
        </div>
        <article className="B2isian">
          <h2>A New Era of Trust in Charity</h2>
          <p className='B2P'>With GiftCare, every donation is recorded on the blockchain a decentralized and immutable ledger that anyone can access. This means you can track your contribution from the moment it's made to the moment it changes a life. No more hidden transactions, no more misplaced trust just pure, verifiable impact.</p>
          <button type="button" id="LMAU">Learn More About Us</button>
        </article>
      </section>
      {/*bagan 3 */}
      <section className="bagan3">
        <h3>Ongoing Charity</h3>
        <div className="card-container">
          {/* Card 1 */}
          <div className="card">
            <img src={Rohingnya} alt="rohingnya" id="gambarblog" />
            <p><b>Rohingya Refugee Relief Fund</b></p>
            <p>Voted by <span>3000 User</span></p>
          </div>
          {/* Card 2 */}
          <div className="card">
            <img src={brazil} alt="Brazil flood" />
            <p><b>Brazil Flood Relief Fund</b></p>
            <p>Voted by <span>3000 User</span></p>
          </div>
          {/* Card 3 */}
          <div className="card">
            <img src={turkey} alt="Turkey earthquake" />
            <p><b>Turkey Earthquake Relief Fund</b></p>
            <p>Voted by <span>3000 User</span></p>
          </div>
        </div>
        <button type="button" id="viewmore">View More</button>
      </section>
      {/* bagan 4 */}
      <section className="bagan4">
        <h4>Visit Our Community</h4>
        <p className='B4p'>connect with like-minded donors and see the impact of your contributions firsthand</p>
        <button type="button" id="JoinTelegram">Join Telegram</button>
      </section>
      {/* footer */}
      <footer class="web3-footer">
        <div class="footer-content">
          <div class="footer-logo">
            <img src={lg2} alt="Company Logo"/>
          </div>
          <div class="footer-community">
            <h4>Join Our Community</h4>
            <p>Connect with us on social media and be part of the conversation.</p>
          </div>
          <div class="footer-social">
            <a href="#"><img src={lgt} alt="tele" id='social'/></a>
            <a href="#"><img src={lgx} alt="x" id='social'/></a>
            <a href="#"><img src={lgd} alt="Discord" id='social'/></a>
          </div>
          <div class="footer-updates">
            <h4>Stay Updated</h4>
            <form>
              <input type="email" placeholder="Enter your email"/>
                <button type="submit">Subscribe</button>
            </form>
          </div>
        </div>
        <div class="footer-bottom">
          <p>let's help those who need us</p>
        </div>
      </footer>

    </main>
  );
}

export default App;
